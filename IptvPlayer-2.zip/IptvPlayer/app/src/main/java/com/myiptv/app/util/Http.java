package com.myiptv.app.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public final class Http {
    private Http() {}

    /** Opens a URL following redirects (including http to https). Caller must close the stream. */
    public static InputStream open(String url) throws IOException {
        String cur = url;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) IPTVPlayer/0.1");
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("تعذر متابعة إعادة التوجيه");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            if (code >= 400) {
                c.disconnect();
                throw new IOException("خطأ من السيرفر (" + code + ")");
            }
            return new BufferedInputStream(c.getInputStream(), 65536);
        }
        throw new IOException("تحويلات كثيرة جداً في الرابط");
    }

    public static String readString(String url) throws IOException {
        try (InputStream in = open(url); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        }
    }
}
