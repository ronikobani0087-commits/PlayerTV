package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Http;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Categories | items | (live preview) screen, used for live channels and movies.
 * Categories and items keep the exact order of the provider.
 */
public class BrowseFragment extends Fragment {
    private static final String ARG_TYPE = "type";
    private static final int ALL_LIMIT = 20000;

    public static BrowseFragment newInstance(String type) {
        BrowseFragment f = new BrowseFragment();
        Bundle a = new Bundle();
        a.putString(ARG_TYPE, type);
        f.setArguments(a);
        return f;
    }

    private String type = "live";
    private long playlistId = -1;
    private boolean showPreview;

    private final CatAdapter catAdapter = new CatAdapter();
    private final ItemAdapter itemAdapter = new ItemAdapter();
    private RecyclerView itemsView;
    private TextView emptyView;

    private PlayerView playerView;
    private TextView previewTitle;
    private TextView previewMessage;
    private ExoPlayer player;
    private Item current;

    private int selectedCat = -1;
    private int loadToken;

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (previewMessage == null) return;
            if (state == Player.STATE_BUFFERING) {
                previewMessage.setText("جارٍ التحميل…");
                previewMessage.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                previewMessage.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (previewMessage == null) return;
            previewMessage.setText("تعذر تشغيل القناة (" + error.getErrorCodeName() + ")");
            previewMessage.setVisibility(View.VISIBLE);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        Bundle args = getArguments();
        type = args == null ? "live" : args.getString(ARG_TYPE, "live");
        int screenW = getResources().getConfiguration().screenWidthDp;
        showPreview = "live".equals(type) && screenW >= 700;
        boolean narrow = screenW < 500;

        FrameLayout frame = new FrameLayout(c);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.HORIZONTAL);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        RecyclerView cats = new RecyclerView(c);
        cats.setLayoutManager(new LinearLayoutManager(c));
        cats.setAdapter(catAdapter);
        cats.setClipToPadding(false);
        cats.setPadding(Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
        cats.setBackgroundColor(ContextCompat.getColor(c, R.color.card));
        root.addView(cats, new LinearLayout.LayoutParams(
                Ui.dp(c, narrow ? 120 : 190), ViewGroup.LayoutParams.MATCH_PARENT));

        itemsView = new RecyclerView(c);
        itemsView.setLayoutManager(new LinearLayoutManager(c));
        itemsView.setAdapter(itemAdapter);
        itemsView.setClipToPadding(false);
        itemsView.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
        root.addView(itemsView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        if (showPreview) {
            root.addView(buildPreview(c), new LinearLayout.LayoutParams(
                    Ui.dp(c, 320), ViewGroup.LayoutParams.MATCH_PARENT));
        }

        emptyView = new TextView(c);
        emptyView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        emptyView.setTextSize(15);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setVisibility(View.GONE);
        frame.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        loadCategories();
        return frame;
    }

    private View buildPreview(Context c) {
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(ContextCompat.getColor(c, R.color.card));
        panel.setPadding(Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10));

        FrameLayout box = new FrameLayout(c);
        box.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(c);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setUseController(false);
        box.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        previewMessage = new TextView(c);
        previewMessage.setTextColor(0xFFFFFFFF);
        previewMessage.setTextSize(13);
        previewMessage.setGravity(Gravity.CENTER);
        previewMessage.setText("اختر قناة للمعاينة");
        box.addView(previewMessage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        panel.addView(box, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 170)));

        previewTitle = new TextView(c);
        previewTitle.setTextColor(ContextCompat.getColor(c, R.color.text));
        previewTitle.setTextSize(16);
        previewTitle.setMaxLines(2);
        previewTitle.setEllipsize(TextUtils.TruncateAt.END);
        previewTitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = Ui.dp(c, 12);
        panel.addView(previewTitle, tp);

        TextView hint = new TextView(c);
        hint.setTextColor(ContextCompat.getColor(c, R.color.muted));
        hint.setTextSize(12);
        hint.setText("اضغط على القناة مرة ثانية لملء الشاشة");
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 6);
        panel.addView(hint, hp);

        TextView full = Ui.button(c, "ملء الشاشة", true);
        full.setOnClickListener(v -> {
            if (current != null) PlayerActivity.start(requireContext(), current.streamUrl, current.name);
        });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.topMargin = Ui.dp(c, 12);
        panel.addView(full, fp);
        return panel;
    }

    // ---------------------------------------------------------------- data

    private void loadCategories() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : dao.getPlaylist(pid);
            final List<Category> list = new ArrayList<>();
            if (p != null) {
                Category all = new Category();
                all.name = "الكل";
                all.remoteId = null;
                list.add(all);
                list.addAll(dao.getCategories(p.id, type));
            }
            final long finalId = p == null ? -1 : p.id;
            Async.main(() -> {
                if (!isAdded()) return;
                playlistId = finalId;
                if (finalId < 0) {
                    showEmpty("لا توجد قائمة مضافة.\nأضف قائمة من الرئيسية.");
                    return;
                }
                if (list.size() <= 1) {
                    showEmpty("لا يوجد محتوى في هذه القائمة.");
                    return;
                }
                emptyView.setVisibility(View.GONE);
                catAdapter.set(list);
                selectCategory(list.size() > 1 ? 1 : 0);
            });
        });
    }

    private void showEmpty(String text) {
        emptyView.setText(text);
        emptyView.setVisibility(View.VISIBLE);
    }

    private void selectCategory(int pos) {
        if (pos < 0 || pos >= catAdapter.data.size()) return;
        int old = selectedCat;
        selectedCat = pos;
        if (old >= 0) catAdapter.notifyItemChanged(old);
        catAdapter.notifyItemChanged(pos);

        final Category cat = catAdapter.data.get(pos);
        final int token = ++loadToken;
        final long pid = playlistId;
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            final List<Item> list = cat.remoteId == null
                    ? dao.itemsAll(pid, type, ALL_LIMIT)
                    : dao.itemsInCategory(pid, type, cat.remoteId);
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                itemAdapter.set(list);
                itemsView.scrollToPosition(0);
            });
        });
    }

    // ------------------------------------------------------------- playback

    @Override
    public void onStart() {
        super.onStart();
        if (showPreview && playerView != null) {
            player = Players.create(requireContext());
            player.addListener(listener);
            playerView.setPlayer(player);
            if (current != null) playPreview(current);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (player != null) {
            player.removeListener(listener);
            if (playerView != null) playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    private void playPreview(Item it) {
        current = it;
        previewTitle.setText(it.name == null ? "" : it.name);
        if (player == null) return;
        previewMessage.setText("جارٍ التحميل…");
        previewMessage.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(it.streamUrl));
        player.prepare();
        player.play();
    }

    private void onItemClick(Item it) {
        if (it.streamUrl == null || it.streamUrl.isEmpty()) {
            if ("series".equals(type)) {
                openSeries(it);
            } else {
                Toast.makeText(requireContext(), "لا يوجد رابط تشغيل لهذا العنصر", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (showPreview && (current == null || current.id != it.id)) {
            playPreview(it);
        } else {
            PlayerActivity.start(requireContext(), it.streamUrl, it.name);
        }
    }

    /** Xtream series: loads the episode list from the server and lets the user pick one. */
    private void openSeries(final Item series) {
        final Context app = requireContext().getApplicationContext();
        final long pid = playlistId;
        Toast.makeText(app, "جارٍ تحميل الحلقات…", Toast.LENGTH_SHORT).show();
        Async.io(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(pid);
                if (p == null || !"xtream".equals(p.type)) throw new Exception("الحلقات غير متاحة لهذه القائمة");
                String uenc = URLEncoder.encode(p.username, "UTF-8");
                String penc = URLEncoder.encode(p.password, "UTF-8");
                String api = p.url + "/player_api.php?username=" + uenc + "&password=" + penc
                        + "&action=get_series_info&series_id=" + URLEncoder.encode(series.remoteId, "UTF-8");
                JSONObject o = new JSONObject(Http.readString(api));
                JSONObject eps = o.optJSONObject("episodes");
                final List<String> titles = new ArrayList<>();
                final List<String> urls = new ArrayList<>();
                if (eps != null) {
                    List<String> seasons = new ArrayList<>();
                    Iterator<String> keys = eps.keys();
                    while (keys.hasNext()) seasons.add(keys.next());
                    Collections.sort(seasons, new Comparator<String>() {
                        @Override
                        public int compare(String a, String b) {
                            return Integer.compare(toInt(a), toInt(b));
                        }
                    });
                    for (String season : seasons) {
                        JSONArray arr = eps.optJSONArray(season);
                        if (arr == null) continue;
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject ep = arr.optJSONObject(i);
                            if (ep == null) continue;
                            String id = ep.optString("id", "");
                            if (id.isEmpty()) continue;
                            String ext = ep.optString("container_extension", "mp4");
                            if (ext.isEmpty()) ext = "mp4";
                            String num = ep.optString("episode_num", String.valueOf(i + 1));
                            String t = ep.optString("title", "");
                            titles.add("الموسم " + season + " · الحلقة " + num + (t.isEmpty() ? "" : " · " + t));
                            urls.add(p.url + "/series/" + uenc + "/" + penc + "/" + id + "." + ext);
                        }
                    }
                }
                Async.main(() -> {
                    if (!isAdded()) return;
                    if (titles.isEmpty()) {
                        Toast.makeText(requireContext(), "لا توجد حلقات لهذا المسلسل", Toast.LENGTH_LONG).show();
                        return;
                    }
                    new AlertDialog.Builder(requireContext())
                            .setTitle(series.name)
                            .setItems(titles.toArray(new String[0]), (d, which) ->
                                    PlayerActivity.start(requireContext(), urls.get(which),
                                            series.name + " - " + titles.get(which)))
                            .show();
                });
            } catch (Exception ex) {
                final String m = ex.getMessage() == null ? "تعذر تحميل الحلقات" : ex.getMessage();
                Async.main(() -> {
                    if (isAdded()) Toast.makeText(requireContext(), m, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    // ------------------------------------------------------------ adapters

    private class CatAdapter extends RecyclerView.Adapter<CatAdapter.VH> {
        List<Category> data = new ArrayList<>();

        void set(List<Category> l) {
            data = l;
            selectedCat = -1;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            TextView tv = new TextView(c);
            tv.setTextColor(ContextCompat.getColor(c, R.color.text));
            tv.setTextSize(13);
            tv.setMaxLines(2);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            tv.setGravity(Gravity.CENTER_VERTICAL);
            tv.setMinHeight(Ui.dp(c, 44));
            tv.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6));
            tv.setBackgroundResource(R.drawable.bg_nav);
            tv.setFocusable(true);
            tv.setClickable(true);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(c, 2);
            tv.setLayoutParams(lp);
            return new VH(tv);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Category cat = data.get(position);
            TextView tv = (TextView) h.itemView;
            tv.setText(cat.name == null ? "" : cat.name);
            tv.setSelected(position == selectedCat);
            tv.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) selectCategory(p);
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        class VH extends RecyclerView.ViewHolder {
            VH(@NonNull View v) {
                super(v);
            }
        }
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
        List<Item> data = new ArrayList<>();

        void set(List<Item> l) {
            data = l;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
            row.setBackgroundResource(R.drawable.bg_card_focus);
            row.setFocusable(true);
            row.setClickable(true);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(c, 6);
            row.setLayoutParams(lp);

            ImageView logo = new ImageView(c);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(logo, new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cp.setMarginStart(Ui.dp(c, 10));
            row.addView(col, cp);

            TextView name = new TextView(c);
            name.setTextColor(ContextCompat.getColor(c, R.color.text));
            name.setTextSize(14);
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            col.addView(name);

            TextView sub = new TextView(c);
            sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
            sub.setTextSize(12);
            sub.setMaxLines(1);
            col.addView(sub);

            return new VH(row, logo, name, sub);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Item it = data.get(position);
            h.name.setText(it.name == null ? "" : it.name);
            String sub = "";
            if (it.year != null && !it.year.isEmpty()) sub = it.year;
            if (it.rating != null && !it.rating.isEmpty() && !"0".equals(it.rating)) {
                sub = sub.isEmpty() ? "★ " + it.rating : sub + "  ★ " + it.rating;
            }
            h.sub.setText(sub);
            h.sub.setVisibility(sub.isEmpty() ? View.GONE : View.VISIBLE);

            Context c = h.itemView.getContext();
            int fallback = "live".equals(type) ? R.drawable.ic_live
                    : ("series".equals(type) ? R.drawable.ic_series : R.drawable.ic_movie);
            if (it.icon != null && it.icon.startsWith("http")) {
                Glide.with(c).load(it.icon).override(120, 120)
                        .placeholder(fallback).error(fallback).into(h.logo);
            } else {
                Glide.with(c).clear(h.logo);
                h.logo.setImageResource(fallback);
            }
            h.itemView.setOnClickListener(v -> onItemClick(it));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        class VH extends RecyclerView.ViewHolder {
            final ImageView logo;
            final TextView name, sub;

            VH(@NonNull View v, ImageView logo, TextView name, TextView sub) {
                super(v);
                this.logo = logo;
                this.name = name;
                this.sub = sub;
            }
        }
    }
}
