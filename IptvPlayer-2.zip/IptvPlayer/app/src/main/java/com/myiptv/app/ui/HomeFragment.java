package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;

public class HomeFragment extends Fragment {
    private TextView subtitle;
    private TextView status;
    private TextView action;
    private TextView refresh;
    private LinearLayout cardsRow;
    private final TextView[] numbers = new TextView[3];
    private long activeId = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(c);
        title.setText("الرئيسية");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(24);
        title.setTypeface(title.getTypeface(), Typeface.BOLD);
        root.addView(title);

        subtitle = new TextView(c);
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(c, 6);
        root.addView(subtitle, sp);

        cardsRow = new LinearLayout(c);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        cardsRow.setVisibility(View.GONE);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = Ui.dp(c, 20);
        cardsRow.addView(card(c, 0, "قناة مباشرة", R.id.nav_live, false));
        cardsRow.addView(card(c, 1, "فيلم", R.id.nav_movies, true));
        cardsRow.addView(card(c, 2, "مسلسل", R.id.nav_series, true));
        root.addView(cardsRow, rp);

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(14);
        status.setLineSpacing(0, 1.3f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = Ui.dp(c, 16);
        root.addView(status, stp);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brp.topMargin = Ui.dp(c, 20);

        action = Ui.button(c, "إضافة قائمة", true);
        row.addView(action);

        refresh = Ui.button(c, "تحديث القائمة", false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.setMarginStart(Ui.dp(c, 10));
        refresh.setOnClickListener(v -> doRefresh());
        refresh.setVisibility(View.GONE);
        row.addView(refresh, fp);

        root.addView(row, brp);
        return scroll;
    }

    private View card(Context c, int index, String label, int navId, boolean withStartMargin) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundResource(R.drawable.bg_card_focus);
        card.setFocusable(true);
        card.setClickable(true);
        card.setPadding(Ui.dp(c, 8), Ui.dp(c, 18), Ui.dp(c, 8), Ui.dp(c, 18));
        card.setOnClickListener(v -> ((MainActivity) requireActivity()).select(navId));

        TextView num = new TextView(c);
        num.setText("—");
        num.setTextColor(ContextCompat.getColor(c, R.color.accent));
        num.setTextSize(26);
        num.setTypeface(num.getTypeface(), Typeface.BOLD);
        num.setGravity(Gravity.CENTER);
        card.addView(num);
        numbers[index] = num;

        TextView lab = new TextView(c);
        lab.setText(label);
        lab.setTextColor(ContextCompat.getColor(c, R.color.muted));
        lab.setTextSize(13);
        lab.setGravity(Gravity.CENTER);
        card.addView(lab);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        if (withStartMargin) lp.setMarginStart(Ui.dp(c, 10));
        card.setLayoutParams(lp);
        return card;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            long id = Prefs.getActive(app);
            Playlist p = id < 0 ? null : db.dao().getPlaylist(id);
            final int live, movies, series;
            if (p == null) {
                live = 0;
                movies = 0;
                series = 0;
            } else {
                live = db.dao().countItems(p.id, "live");
                movies = db.dao().countItems(p.id, "movie");
                series = db.dao().countItems(p.id, "series");
            }
            final long pid = p == null ? -1 : p.id;
            final String name = p == null ? "" : p.name;
            final long updated = p == null ? 0 : p.updatedAt;
            Async.main(() -> {
                if (!isAdded() || status == null) return;
                activeId = pid;
                NumberFormat nf = NumberFormat.getInstance();
                if (pid < 0) {
                    subtitle.setText("");
                    cardsRow.setVisibility(View.GONE);
                    status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
                } else {
                    String when = updated > 0
                            ? "  ·  آخر تحديث: " + DateFormat.getDateTimeInstance(
                            DateFormat.SHORT, DateFormat.SHORT).format(new Date(updated))
                            : "";
                    subtitle.setText(name + when);
                    cardsRow.setVisibility(View.VISIBLE);
                    numbers[0].setText(nf.format(live));
                    numbers[1].setText(nf.format(movies));
                    numbers[2].setText(nf.format(series));
                    status.setText("");
                }
                refresh.setVisibility(pid < 0 ? View.GONE : View.VISIBLE);
                action.setText(pid < 0 ? "إضافة قائمة" : "إدارة القوائم");
                action.setOnClickListener(v -> {
                    MainActivity a = (MainActivity) requireActivity();
                    if (activeId < 0) a.openAddPlaylist();
                    else a.select(R.id.nav_settings);
                });
            });
        });
    }

    private void doRefresh() {
        if (activeId < 0) return;
        refresh.setEnabled(false);
        SyncRepository.sync(requireContext(), activeId, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                load();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("تعذر التحديث: " + message);
            }
        });
    }
}
