package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "playlists")
public class Playlist {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String name;
    /** "xtream" or "m3u" */
    public String type;
    public String url;
    public String username;
    public String password;
    public long updatedAt;
}
